// calculadora.test.js
const fs = require('fs');
const path = require('path');

let display;
let calcular;

beforeEach(() => {
    document.body.innerHTML = fs.readFileSync(path.resolve(__dirname, '../src/index.html'), 'utf-8');
    display = document.getElementById('display');
    calcular = document.getElementById('igual');
});

test('deve calcular a soma corretamente', () => {
    document.getElementById('tecla2').click();
    document.getElementById('operadorAdicionar').click();
    document.getElementById('tecla3').click();
    calcular.click();

    expect(display.textContent).toBe('5');
});

test('deve calcular a subtração corretamente', () => {
    document.getElementById('tecla5').click();
    document.getElementById('operadorSubtrair').click();
    document.getElementById('tecla2').click();
    calcular.click();

    expect(display.textContent).toBe('3');
});

test('deve calcular a multiplicação corretamente', () => {
    document.getElementById('tecla4').click();
    document.getElementById('operadorMultiplicar').click();
    document.getElementById('tecla2').click();
    calcular.click();

    expect(display.textContent).toBe('8');
});

test('deve calcular a divisão corretamente', () => {
    document.getElementById('tecla8').click();
    document.getElementById('operadorDividir').click();
    document.getElementById('tecla4').click();
    calcular.click();

    expect(display.textContent).toBe('2');
});

test('deve limpar o display', () => {
    document.getElementById('tecla5').click();
    document.getElementById('limparDisplay').click();
    
    expect(display.textContent).toBe('0');
});

test('deve limpar todos os cálculos', () => {
    document.getElementById('tecla3').click();
    document.getElementById('operadorAdicionar').click();
    document.getElementById('tecla7').click();
    document.getElementById('limparCalculo').click();

    expect(display.textContent).toBe('0');
});
